﻿namespace OlympicGames.Olympics.Enums
{
    public enum BoxingCategory
    {
        Flyweight,
        Featherweight,
        Lightweight,
        Middleweight,
        Heavyweight
    }
}
