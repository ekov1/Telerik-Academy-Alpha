﻿namespace Traveller.Core.Contracts.ProviderContracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
