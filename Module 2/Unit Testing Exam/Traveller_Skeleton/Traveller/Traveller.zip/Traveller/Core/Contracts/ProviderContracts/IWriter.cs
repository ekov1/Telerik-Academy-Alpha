﻿namespace Traveller.Core.Contracts.ProviderContracts
{
    public interface IWriter
    {
        void Write(string message);
    }
}
